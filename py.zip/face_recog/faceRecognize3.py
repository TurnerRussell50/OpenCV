import face_recognition
import cv2
import os
print(cv2.__version__)


Encodings=[]
Names=[]

image_dir='/home/tom/Desktop/pyPro/face_recog/demoimages/known'
for root, dirs, files in os.walk(image_dir):
    print(files)
    for file in files:
        path=os.path.join(root,file)
        print(path)